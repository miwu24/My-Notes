N = 10;
Matrix = [beta(N) gam(N) mu(N)]