function [ X_N ] = X( N )
%X Summary of this function goes here
%   Detailed explanation goes here
J = [0:N]';
X_N = -1 + 2*J/N;
end

