function [ y ] = f( x )
%F Summary of this function goes here
%   Detailed explanation goes here
y = cos(x)-x;

end

