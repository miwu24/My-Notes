%% This function computes the kth extremum of T_n
function [Ext] = Extrema(n,k)
%EXTREMA Summary of this function goes here
%   Detailed explanation goes here
Ext = cos(k*pi/n);
end

