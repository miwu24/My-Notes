function [ y ] = f_1d_1( x )
%F_1D Summary of this function goes here
%   Detailed explanation goes here
e = exp(1);
y = e^(2*x)*sin(3*pi*x);
end

