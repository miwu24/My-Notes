function [ y ] = f_1d_2( x )
%F_1D_2 Summary of this function goes here
%   Detailed explanation goes here
y = abs(x);

end

