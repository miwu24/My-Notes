x=[0,1,1.5,2];
y=[-1,3,2,4];
c = dividiff(x,y)