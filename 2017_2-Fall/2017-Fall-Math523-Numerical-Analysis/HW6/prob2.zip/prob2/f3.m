function [ v_f ] = f3(t)
%F3 Summary of this function goes here
%   Detailed explanation goes here
v_f = sqrt(t);

end

