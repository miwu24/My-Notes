function [ v_f ] = f2( t )
%F2 Summary of this function goes here
%   Detailed explanation goes here
v_f = abs(t-0.1);

end

