function [ v_f ] = f1( t )
%F1 Summary of this function goes here
%   Detailed explanation goes here
v_f = 2/sqrt(pi)*exp(-t^2);

end

