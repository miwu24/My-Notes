tol = 0.01;
%%% This is for f1
[Q,n] = adapt_quad('f1',0,1,tol);
Q
n

%%% This is for f1
[Q,n] = adapt_quad('f2',0,1,tol);
Q
n

%%% This is for f1
[Q,n] = adapt_quad('f3',0,1,tol);
Q
n