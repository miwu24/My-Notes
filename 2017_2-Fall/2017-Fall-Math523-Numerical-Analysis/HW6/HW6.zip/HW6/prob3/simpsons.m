function Q = simpsons(f,a,b,n)
PanelNodes = linspace(a,b,n+1);
MiddleNodes = linspace(a+(b-a)/(2*n),b-(b-a)/(2*n),n);
Q = (b-a)/(6*n)*(dot(arrayfun(@(x) feval(f,x),PanelNodes),[1,2*ones(1,n-1),1])+4*sum(arrayfun(@(x) feval(f,x),MiddleNodes)));
end