function [Q,n] = adapt_quad(f,a,b,tol)
%ADAPT_QUAD Summary of this function goes here
%   Detailed explanation goes here
k = 0;
Q = simpsons(f,a,b,2^k);
I = simpsons(f,a,b,2^(k+1));
while abs(I-Q)>tol
    k=k+1;
    Q = I;
    I = simpsons(f,a,b,2^(k+1));
end
n = 2^k;
end

