function [ B, Passed ] = Test( h, Sample )
%TEST Summary of this function goes here
%   Detailed explanation goes here
Total = size(Sample,1);
Passed = sum(sum(abs(Sample)<=h/2,2)==2);
if Passed==0.1*Total
    B = true; %% B = Boolean
else
    B = false;
end
end

