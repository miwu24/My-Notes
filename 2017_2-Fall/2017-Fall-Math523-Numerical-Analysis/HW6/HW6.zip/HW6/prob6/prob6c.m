%%%%% p = 1
n = 4*10^5;
Sample = randn(1,n);
Estimate1 = sum(Sample.^2)/n

%%%%% p = 2
n = 2.13*10^6;
Sample = randn(1,n);
Estimate2 = sum(Sample.^4)/n

%%%%% p = 5
n = 1.46*10^8;
Sample = randn(1,n);
Estimate3 = sum(Sample.^10)/n



