
n = 10^6;
Sample = Box_Muller(n);
h0 = 0;
h = 1/2;
h1 = 1;
[ B, Passed ] = Test( h, Sample );
while B==0
    if Passed<0.1*n
        h0 = h;
        h = (h+h1)/2;
        [ B, Passed ] = Test( h, Sample );
    elseif Passed>0.1*n
        h1 = h;
        h = (h0+h)/2;
        [ B, Passed ] = Test( h, Sample );
    end
end
h 
fun = @(x,y) 1./(2*pi).*exp(-(x.^2+y.^2)/2);
I_MC = quad2d(fun,-h/2,h/2,-h/2,h/2) %% MC = Monte-Carlo





