function [ ETA ] = Box_Muller( n )
%BOX_MULLER Summary of this function goes here
%   Detailed explanation goes here
Psi1 = rand(n,1);
Psi2 = rand(n,1);
Eta1 = sqrt(-2*log(Psi1)).*cos(2*pi*Psi2);
Eta2 = sqrt(-2*log(Psi1)).*sin(2*pi*Psi2);
ETA = [Eta1 Eta2];
end

